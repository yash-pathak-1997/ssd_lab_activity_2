For Question1:

	Command to run:
		chmod +x q1.sh
		chmod +xrw filename
		./q1.sh filename

For Question2:
	
	Commands to run:
		chmod +x q2.sh
		./q2.sh

